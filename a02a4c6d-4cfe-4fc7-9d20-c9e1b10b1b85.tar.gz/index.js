require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Events, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { convertScript } = require('./utils/converter');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const TOKEN = process.env.TOKEN;
const CHANNEL_ID = '1399770775610720368'; // Promeni po potrebi

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ],
});

client.commands = new Collection();

// Učitaj sve komande iz commands foldera
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        // Moderno: koristi command.data.name
        client.commands.set(command.data.name, command);
    }
}

client.once('ready', () => {
    console.log(`Ulogovan kao ${client.user.tag}`);

    const channel = client.channels.cache.get(CHANNEL_ID);
    if (channel) {
        const embed = new EmbedBuilder()
            .setTitle('Host je upaljen!')
            .setColor(0x00ff00);
        channel.send({ embeds: [embed] }).catch(console.error);
    } else {
        console.error('Kanal nije pronađen!');
    }
});

client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isCommand()) return;
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(error);
        await interaction.reply({ content: 'Desila se greška prilikom izvršavanja komande!', ephemeral: true });
    }
});

// Automatska konverzija svih .lua fajlova na upload
client.on('messageCreate', async message => {
    if (message.author.bot || !message.attachments.size) return;

    for (const attachment of message.attachments.values()) {
        if (!attachment.name.endsWith('.lua')) continue;
        try {
            const response = await fetch(attachment.url);
            const text = await response.text();
            const qbCode = convertScript(text);
            const file = new AttachmentBuilder(Buffer.from(qbCode), { name: `converted_${attachment.name}` });
            await message.reply({ files: [file] });
        } catch (err) {
            console.error(err);
            await message.reply('Greška pri konverziji fajla.');
        }
    }
});

client.login(TOKEN);
