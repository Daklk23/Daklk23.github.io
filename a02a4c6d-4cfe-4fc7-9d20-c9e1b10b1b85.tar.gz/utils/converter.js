// utils/converter.js
const conversionMap = {
  // ───────── ESX ⇢ QBCore Shared Object ─────────
// ESX = exports['es_extended']:getSharedObject()  ili  ESX = exports["es_extended"]:getSharedObject()
"^\\s*ESX\\s*=\\s*exports\\[([\"'])es_extended\\1\\]:getSharedObject\\(\\s*\\)": 
    "local QBCore = exports['qb-core']:GetCoreObject()",

// inline getSharedObject (bez direktne dodele u varijablu)
"exports\\[([\"'])es_extended\\1\\]:getSharedObject\\(\\s*\\)": 
    "exports['qb-core']:GetCoreObject()",

// TriggerEvent('esx:getSharedObject', function(...)
"TriggerEvent\\(([\"'])esx:getSharedObject\\1,?\\s*function\\(": 
    "local QBCore = exports['qb-core']:GetCoreObject()",


  // ───────── Server-side callbacks & usable items ─────────
  "ESX\\.RegisterServerCallback":                                  "QBCore.Functions.CreateCallback",
  "ESX\\.TriggerServerCallback":                                   "QBCore.Functions.TriggerCallback",
  "ESX\\.RegisterUsableItem":                                      "QBCore.Functions.CreateUseableItem",
  "TriggerEvent\\('esx:registerUsableItem',":                      "QBCore.Functions.CreateUseableItem",

  // ───────── Commands ─────────
  "ESX\\.RegisterCommand":                                         "QBCore.Commands.Add",
  "RegisterCommand\\('esx:([\\w_]+)'":                             "QBCore.Commands.Add('$1'",

  // ───────── Trigger Events ─────────
  "TriggerServerEvent\\('esx:([\\w_]+)'":                          "TriggerServerEvent('QBCore:Server:$1'",
  "TriggerClientEvent\\('esx:([\\w_]+)'":                          "TriggerClientEvent('QBCore:Client:$1'",

  // ───────── Net Events ─────────
  "RegisterNetEvent\\('esx:playerLoaded'":                         "RegisterNetEvent('QBCore:Client:OnPlayerLoaded'",
  "RegisterNetEvent\\('esx:([\\w_]+)'":                            "RegisterNetEvent('QBCore:Client:$1'",

  // ───────── Player Data ─────────
  "ESX\\.GetPlayerData":                                           "QBCore.Functions.GetPlayerData()",
  "ESX\\.GetPlayerFromId\\((.*?)\\)":                              "QBCore.Functions.GetPlayer(tonumber($1))",

  // xPlayer ⇢ Player.PlayerData
  "\\bxPlayer\\.identifier\\b":                                    "Player.PlayerData.citizenid",
  "\\bxPlayer\\.job\\.name\\b":                                    "Player.PlayerData.job.name",
  "\\bxPlayer\\.job\\.grade\\b":                                   "Player.PlayerData.job.grade.level",
  "\\bxPlayer\\b":                                                 "Player",

  // ───────── Inventory, Money & Weapons ─────────
  "xPlayer\\.addInventoryItem\\(([^)]+)\\)":                       "Player.Functions.AddItem($1)",
  "xPlayer\\.removeInventoryItem\\(([^)]+)\\)":                    "Player.Functions.RemoveItem($1)",
  "xPlayer\\.addMoney\\(([^)]+)\\)":                               "Player.Functions.AddMoney('money', $1)",
  "xPlayer\\.removeMoney\\(([^)]+)\\)":                            "Player.Functions.RemoveMoney('money', $1)",
  "xPlayer\\.addWeapon\\(([^)]+)\\)":                              "Player.Functions.AddWeapon($1)",
  "xPlayer\\.removeWeapon\\(([^)]+)\\)":                           "Player.Functions.RemoveWeapon($1)",

  // ───────── Notifications & UI ─────────
  "ESX\\.ShowNotification":                                        "QBCore.Functions.Notify",
  "ESX\\.ShowHelpNotification":                                    "QBCore.Functions.HelpNotify",
  "ESX\\.UI\\.Menu\\.Open":                                        "exports['qb-menu']:openMenu",
  "ESX\\.UI\\.Menu\\.CloseAll":                                    "exports['qb-menu']:closeMenu",

  // ───────── Vehicles & Models ─────────
  "ESX\\.Game\\.SpawnVehicle":                                     "QBCore.Functions.SpawnVehicle",
  "ESX\\.Game\\.DeleteVehicle":                                    "QBCore.Functions.DeleteVehicle",
  "ESX\\.Game\\.GetVehicles":                                      "QBCore.Functions.GetVehicles",
  "ESX\\.Game\\.GetVehicleProperties":                             "QBCore.Functions.GetVehicleProperties",
  "ESX\\.Game\\.SetVehicleProperties":                             "QBCore.Functions.SetVehicleProperties",
  "ESX\\.Game\\.SpawnLocalPed":                                    "QBCore.Functions.SpawnLocalPed",
  "ESX\\.Streaming\\.RequestModel":                                "QBCore.Functions.LoadModel",

  // 3D text
  "ESX\\.Game\\.Utils\\.DrawText3D":                               "exports['qb-core']:DrawText3D",

  // ───────── Timing ─────────
  "ESX\\.SetTimeout":                                              "SetTimeout",
  "ESX\\.ClearTimeout":                                            "ClearTimeout",
  "ESX\\.Sleep":                                                   "Wait",

  // ───────── Progress Bars & Status ─────────
  "exports\\['esx_status'\\]":                                     "exports['qb-core']",
  "TriggerEvent\\('esx_status:add',":                              "TriggerEvent('QBCore:Client:UpdateStatus'",
  "exports\\['progressBars'\\]":                                   "exports['qb-taskbar']",

  // ───────── Society & BossMenu ─────────
  "TriggerServerEvent\\('esx_society:openBossMenu',":              "TriggerServerEvent('qb-bossmenu:server:openMenu'",
  "TriggerEvent\\('esx_society:getSociety',":                      "TriggerEvent('qb-bossmenu:getSociety'",

  // ───────── Phone ─────────
  "exports\\['esx_qalle_phone'\\]":                                "exports['qb-phone']",
  "TriggerClientEvent\\('esx_phone:onMessage',":                   "TriggerClientEvent('QBCore:Client:Phone:OnMessage'",
  "TriggerClientEvent\\('esx_phone:newEvent',":                    "TriggerClientEvent('QBCore:Client:Phone:NewEvent'",

  // ───────── Animations & Emotes ─────────
  "TaskPlayAnim":                                                  "TaskPlayAnim",
  "ClearPedTasks":                                                 "ClearPedTasks",

  // ───────── Logging ─────────
  "print\\(":                                                      "console.log(",

  // ───────── Database ─────────
  "MySQL\\.Async\\.fetchAll":                                      "exports['ghmattimysql']:execute",
  "MySQL\\.Async\\.execute":                                       "exports['ghmattimysql']:execute",
  "MySQL\\.Sync\\.fetchAll":                                       "exports['oxmysql']:fetch",
  "MySQL\\.Sync\\.execute":                                        "exports['oxmysql']:execute",

  // ───────── Police & Ambulance Jobs ─────────
  "TriggerClientEvent\\('esx_policejob:handcuff',":                "TriggerEvent('police:client:HandcuffPlayer'",
  "TriggerClientEvent\\('esx_ambulancejob:revive',":               "TriggerEvent('ambulance:client:RevivePlayer'",

  // ───────── Identity & Steam ─────────
  "exports\\['esx_identity'\\]":                                   "exports['qb-core']",
  "getIdentity":                                                   "exports['qb-core']:GetPlayerData",

  // ───────── Misc ─────────
  "ESX\\.ShowAdvancedNotification":                                "QBCore.Functions.Notify"
};

function convertScript(esxCode) {
    let qbCode = esxCode;
    for (const [pattern, replacement] of Object.entries(conversionMap)) {
        const regex = new RegExp(pattern, 'g');
        qbCode = qbCode.replace(regex, typeof replacement === 'function' ? replacement : replacement);
    }
    return qbCode;
}

module.exports = { convertScript };
