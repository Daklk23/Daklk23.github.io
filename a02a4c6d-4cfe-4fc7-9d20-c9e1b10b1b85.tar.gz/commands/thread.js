const { SlashCommandBuilder, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('thread')
        .setDescription('Kreiraj thread za upload fajlova za konverziju ESX → QBCore!'),
    async execute(interaction) {
        const channel = interaction.channel;
        if (!channel) {
            return await interaction.reply({ content: 'Greška: Nema kanala!', ephemeral: true });
        }
        const thread = await channel.threads.create({
            name: `conversion-${Date.now()}`,
            autoArchiveDuration: 60,
            type: ChannelType.PublicThread
        });
        await thread.send('Upload your .lua file here, and I will convert it automatically.');
        await interaction.reply({ content: `Thread created: <#${thread.id}>`, ephemeral: true });
    }
};
