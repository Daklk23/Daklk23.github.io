const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Obriši zadati broj poruka iz kanala')
        .addIntegerOption(option =>
            option
                .setName('count')
                .setDescription('Broj poruka za brisanje (2-100)')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .setDMPermission(false),
    async execute(interaction) {
        const count = interaction.options.getInteger('count');
        if (count < 2 || count > 100) {
            return await interaction.reply({ content: 'Možeš obrisati između 2 i 100 poruka!', ephemeral: true });
        }

        // Brisanje poruka
        try {
            await interaction.channel.bulkDelete(count, true);
            await interaction.reply({ content: `Obrisano ${count} poruka.`, ephemeral: true });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'Nisam mogao da obrišem poruke (možda su starije od 14 dana ili nemam permisije).', ephemeral: true });
        }
    }
};
